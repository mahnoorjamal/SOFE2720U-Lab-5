<?php
session_start();
include 'list_database.php'; 

if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit;
}


$userId = $_SESSION['user_id'];
$error_message = $success_message = '';

// Handle marking a task as complete

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_task') {
    $taskId = $_POST['task_id'];
    $status = $_POST['status'] === 'completed' ? 'completed' : 'pending';
    
    // Here, set the completion date only if the task is being completed
    $completionDate = $status === 'completed' ? date('Y-m-d H:i:s') : null;
    // Ensure you validate the $taskId to be an integer and belongs to the user
    $stmt = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ? AND user_id = ?");
    if ($stmt->execute([$status, $taskId, $userId])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

// Handle task submission
if ($_SERVER['REQUEST_METHOD'] == 'POST'&& isset($_POST['action']) && $_POST['action'] === 'add_task') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $priority = $_POST['priority'] ?? '';
    $due_date = $_POST['due_date'] ?? '';

    if (empty($title) || empty($description) || empty($priority) || empty($due_date)) {
        $error_message = "Please fill in all required fields.";
    } else {
        $query = "INSERT INTO tasks (user_id, title, description, priority, due_date) VALUES (:user_id, :title, :description, :priority, :due_date)";
        $stmt = $pdo->prepare($query);
        
        if ($stmt->execute([':user_id' => $userId, ':title' => $title, ':description' => $description, ':priority' => $priority, ':due_date' => $due_date])) {
            
            $success_message = "Task added successfully!";
            echo '<div id="task-added-success-message" class="success-message">' . htmlspecialchars($success_message) .
     '</div>';

            // Echo the inline script that hides the success message after 5 seconds
            echo '<script type="text/javascript">
                    setTimeout(function() {
                        var message = document.getElementById("task-added-success-message");
                        if (message) {
                            message.style.display = "none";
                        }
                    }, 2000);
                </script>';
        } else {
            $error_message = "Error adding task.";
        }
    }
}

// Fetch tasks
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ? AND status != 'completed' ORDER BY FIELD(priority, 'High', 'Medium', 'Low'), due_date ASC");
$stmt->execute([$userId]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
// After your database connection setup

// Fetch completed tasks
$stmt_completed = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ? AND status = 'completed' ORDER BY completion_date DESC LIMIT 5");
$stmt_completed->execute([$userId]);
$completed_tasks = $stmt_completed->fetchAll(PDO::FETCH_ASSOC);


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] === 'uncomplete_task') {
    $taskId = $_POST['task_id'];
    // Ensure you validate the $taskId to be an integer and belongs to the user
    $stmt = $pdo->prepare("UPDATE tasks SET status = 'pending' WHERE id = ? AND user_id = ?");
    if ($stmt->execute([$taskId, $userId])) {
        echo json_encode(['success' => true, 'message' => 'Task unmarked as completed']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error unmarking task as completed']);
    }
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Tasks</title>
    <link rel="stylesheet" href="tasks.css">
    <link rel="icon" type="image/png" href="listlogo.png">
</head>
<body>
        
    <?php if (!empty($error_message)): ?>
        <p style="color: red;"><?= htmlspecialchars($error_message) ?></p>
    <?php endif; ?>
    
    <div class="layout-wrapper">
        <div class="sidebar">
            
            <div class="user-widget">
                <div class="profile-top">
                    <img src="profiletop.png" alt="Profile Top Image" class="decorative-icon"/>
                </div>

                <div class="welcome-section">
                    <img src="<?= file_exists("profile_pictures/" . $_SESSION['user_id'] . ".jpg") ? "profile_pictures/" . $_SESSION['user_id'] . ".jpg" : "placeholder-profile.png" ?>" alt="Profile Icon" class="profile-image">
                    <div class="user-info">
                        <h2>Welcome <?= $_SESSION['username'] ?> </h2>

                    </div>
                </div>
                <div class="user-actions">
                    <form action="profile.php" method="post">
                        <button type="submit" class="learn-more">Profile</button>
                    </form>
                    <form action="logout.php" method="post">
                        <button type="submit" class="learn-more">Logout</button>
                    </form>
                </div>
            </div>

            <?php
                $currentDay = date('j'); // Day of the month without leading zeros
                $currentMonth = date('F'); // Full textual representation of a month
                $currentYear = date('Y'); // A full numeric representation of a year, 4 digits
            ?>

            <div class="cute-calendar">
                <div class="calendar-header">
                    <img src="calendar2.png" alt="Decorative Icon" class="month-icon"/>
                    <span class="month"><?= $currentMonth ?></span>
                    <span class="year"><?= $currentYear ?></span>
                </div>
                <div class="calendar-grid">
                    <!-- Days of the week -->
                    <div class="day">Sun</div>
                    <div class="day">Mon</div>
                    <div class="day">Tue</div>
                    <div class="day">Wed</div>
                    <div class="day">Thu</div>
                    <div class="day">Fri</div>
                    <div class="day">Sat</div>
                    <?php
                        $numDays = date('t'); // Number of days in the current month
                        for ($day = 1; $day <= $numDays; $day++):
                            $class = ($day == $currentDay) ? 'date today' : 'date'; // Highlight the current day
                        ?>
                            <div class="<?= $class ?>"><?= $day ?></div>
                        <?php endfor; ?>
                        </div>
                    </div>
                    
                <div class="completed-tasks-widget">
                    <img src="corner.png" alt="Top Left Corner" class="corner-image top-left"/>
                    
                    <h3>Your Recently Completed Tasks</h3>
                    <ul>
                        <!-- Dynamically generate list items for completed tasks -->
                        <?php foreach ($completed_tasks as $task): ?>
                        <li><?= htmlspecialchars($task['title']) ?></li>
                    <?php endforeach; ?>
                    </ul>
                </div>

                    <!-- Placeholder for Weather Widget -->
                    <div id="weather-widget">
                    <div class="card">
            <div class="container">
                <div class="cloud front">
                <span class="left-front"></span>
                <span class="right-front"></span>
                </div>
                <span class="sun sunshine"></span>
                <span class="sun"></span>
                <div class="cloud back">
                <span class="left-back"></span>
                <span class="right-back"></span>
                </div>
            </div>

            <div class="card-header">
                <span>Toronto, Ontario<br>Canada</span>
                <span>March 13</span>
            </div>

            <span class="temp">23°</span>

            <div class="temp-scale">
                <span>Celcius</span>
            </div>
            </div>
                    </div>
                </div>
        </div>
        <div class="content">
            <div class="tasks-header">
                <img src="Your Task.png" alt="Task Icon" class="tasks-icon"/>
                <h2>Your Tasks</h2>
            </div>
            <div id="no-tasks-container" style="display: <?php echo count($tasks) === 0 ? 'block' : 'none'; ?>;">
            <p>You have no tasks.</p>
            </div>
            <?php if (count($tasks) > 0): ?>
                
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Priority</th>
                        <th>Due Date</th>
                        <th>Completion</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($tasks as $task): ?>
                <tr>
                    <td><?= htmlspecialchars($task['title']) ?></td>
                    <td><?= htmlspecialchars($task['description']) ?></td>
                    <td><?= htmlspecialchars($task['priority']) ?></td>
                    <td><?= htmlspecialchars($task['due_date']) ?></td>
                    <td>
                        <?php if ($task['status'] === 'completed'): ?>
                            <label class="switch">
                            <input type="checkbox" checked onchange="toggleTaskStatus(<?= $task['id'] ?>, this)">
                            <span class="slider round"></span>
                            </label>
                        <?php else: ?>
                            <label class="switch">
                            <input type="checkbox" onchange="toggleTaskStatus(<?= $task['id'] ?>, this)">
                            <span class="slider"></span>
                            </label>
                        <?php endif; ?>
                    </td>
                    <td>
                        <!-- Edit Button -->
                        <form action="edit.php" method="get" style="display: inline;">
                            <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                            <button type="submit" class="learn-more">Edit</button>
                        </form>
                        <!-- Delete Button -->
                        <form action="delete.php" method="post" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this task?');">
                            <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                            <button type="submit" class="learn-more">Delete</button>
                        </form>
                    </td>
                    </tbody>
                </tr>
                <?php endforeach; ?>
                
            </table>
            <?php else: ?>
            
            <?php endif; ?>

            <h3>
            <img src="newtask.png" alt="Add Task Icon" class="add-task-icon"/>
                Add New Task
            </h3>
            <form action="tasks.php" method="post">
            <div class="input-wrapper">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required><br>
            </div>
            <div class="input-wrapper">
                <label for="description">Description:</label>
                <textarea id="description" name="description" required></textarea><br>
            </div>
            <div class="input-wrapper">
                <label for="priority">Priority:</label>
                <select id="priority" name="priority" required>
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                </select><br>
            </div>
            <div class="input-wrapper">
                <label for="due_date">Due Date:</label>
                <input type="date" id="due_date" name="due_date" required><br>
            </div>
                <input type="hidden" name="action" value="add_task">
                <button type="submit" class="learn-more" value="Add Task"> Add Task </button>
                
            </form>
        </div> 
   
    </div>            
    <script>




function toggleTaskStatus(taskId, element) {
  const isCompleted = element.checked;
  const formData = new FormData();
  formData.append('task_id', taskId);
  formData.append('action', 'toggle_task');
  formData.append('status', isCompleted ? 'completed' : 'pending');

  fetch('tasks.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Delay moving the task to the completed list
      setTimeout(() => {
        const taskRow = element.closest('tr');
        if (taskRow) {
          if (isCompleted) {
            const completedList = document.querySelector('.completed-tasks-widget ul');
            const newTask = document.createElement('li');
            newTask.textContent = taskRow.cells[0].textContent; // Assuming the title is in the first cell
            completedList.appendChild(newTask);
          }
          taskRow.remove();
          checkTasksList(); // Check if there are any tasks left
        }
      }, 3000); // Wait for 5 seconds before executing the above code
    } else {
      element.checked = !isCompleted; // Revert the checkbox state if the update fails
      alert('Error toggling task status');
    }
  })
  .catch(error => {
    console.error('Error:', error);
    alert('Failed to toggle task status');
    element.checked = !isCompleted; // Revert the checkbox state if there's a problem with the fetch call
  });
}

function checkTasksList() {
  const tasksCount = document.querySelectorAll('.content table tbody tr').length;
  const taskTable = document.querySelector('.content table');
  const noTasksMessage = document.getElementById('no-tasks-container');

  if (tasksCount === 0) {
    taskTable.style.display = 'none';
    noTasksMessage.style.display = 'block';
  } else {
    taskTable.style.display = 'table';
    noTasksMessage.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', checkTasksList);
setTimeout(function() {
  checkTasksList();
}, 800);


document.addEventListener('DOMContentLoaded', function() {
    // Hide the success message after 5 seconds
    var successMessage = document.getElementById('task-added-success-message');
    if (successMessage) {
        setTimeout(function() {
            successMessage.style.opacity = '0';
        }, 5000);
    }
    
    // Other existing code...
});


</script>  
</body>
</html>
