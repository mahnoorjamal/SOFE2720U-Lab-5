<?php
session_start();
include 'list_database.php'; 

if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect to the login page
    header('Location: login.html');
    exit;
}

$userId = $_SESSION['user_id'];

// Check if task_id is set
if (isset($_POST['task_id'])) {
    $taskId = $_POST['task_id'];

    // Validate that the task belongs to the user
    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?");
    $stmt->execute([$taskId, $userId]);
    $task = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($task) {
        // Delete the task
        $deleteStmt = $pdo->prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?");
        $deleteStmt->execute([$taskId, $userId]);
        
        $_SESSION['flash_success'] = 'Task deleted successfully.';
    } else {
        $_SESSION['flash_error'] = 'Task not found or does not belong to you.';
    }
} else {
    $_SESSION['flash_error'] = 'No task specified for deletion.';
}

header('Location: tasks.php');
exit;
?>
