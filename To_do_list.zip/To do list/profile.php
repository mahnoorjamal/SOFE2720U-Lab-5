<?php
session_start();
include 'list_database.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit;
}

$userId = $_SESSION['user_id'];

// Fetch user details
$stmt = $pdo->prepare("SELECT username, email, password FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <link rel="stylesheet" href="profile.css">
    <link rel="icon" type="image/png" href="listlogo.png">
</head>
<body>
<div class="container">
    <div class="header-container">
            <h1>Hi <?= $_SESSION['username'] ?> </h1>
            <img src="mini.png" alt="Greeting Icon" class="greeting-image"/>
    </div>
    
    <div class="profile-section">
        <div class="left-column">
            <div class="profile-pic">
                <?php if (file_exists("profile_pictures/" . $userId . ".jpg")): ?>
                    <img src="profile_pictures/<?= $userId ?>.jpg" alt="Profile Picture" />
                <?php else: ?>
                    <img src="placeholder-profile.png" alt="Default Profile Picture">
                <?php endif; ?>
            </div>
            <button onclick="window.location.href='tasks.php'" class="learn-more">Back to Tasks</button>
        </div>

        
        <div class="profile-details">
            <form action="update_profile.php" method="post" enctype="multipart/form-data">
                <div class="input-wrapper">
                    Username: <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>">
                
                </div>
                <div class="input-wrapper">
                    Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>">
                </div>
                <div class="input-wrapper">
                    Password: <input type="password" name="password">
                </div>
                <div class="input-wrapper">
                    Profile Picture: <input type="file" name="profile_picture">
                    <small>Please upload JPG files only.</small>
                </div>
                <div>
                    <button type="submit" name="update_profile" class="learn-more" >Update Profile</button>
                    <label class="checkbox-container">
                        <input class="custom-checkbox" type="checkbox" name="reset_picture" value="1"> Reset to default profile picture
                        <span class="checkmark"></span> 
                    </label>
                </div>
            </form>
        </div>
    </div>
    
</div>
</body>
</html>