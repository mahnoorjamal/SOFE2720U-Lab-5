<?php
session_start();
include 'list_database.php';

// Redirect if not logged in or no POST data
if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: profile.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Retrieve and sanitize form data
$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Update user details

$pdo->beginTransaction();

// If a new password is provided, include it in the update
if (!empty($password)) {
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $updateQuery = "UPDATE users SET username = ?, email = ?, password = ?, profile_pic = ? WHERE id = ?";
    $updateStmt = $pdo->prepare($updateQuery);
    // Prepare the profile picture filename
    $profilePicFilename = null; // Default to null
} else {
    $updateQuery = "UPDATE users SET username = ?, email = ?, profile_pic = ? WHERE id = ?";
    $updateStmt = $pdo->prepare($updateQuery);
    // Prepare the profile picture filename
    $profilePicFilename = null; // Default to null
}

// Handle profile picture upload
if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
    $tmp_name = $_FILES['profile_picture']['tmp_name'];
    
    $target_dir = "profile_pictures/";
    $fileExtension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
    $target_file = $target_dir . $userId . '.' . $fileExtension;

    // You should also validate the file (size, type, etc.)

    // Move the uploaded file
    if (move_uploaded_file($tmp_name, $target_file)) {
        // File upload success
        // Assign the filename to the variable for database update
        $profilePicFilename = $userId . '.' . $fileExtension;
    } else {
        // Add an error message if the upload fails
        $errors[] = "There was an error uploading the profile picture.";
    }
}

// Update the database if there are no errors
if (empty($errors)) {
    if (!empty($password)) {
        $updateStmt->execute([$username, $email, $hashedPassword, $profilePicFilename, $userId]);
    } else {
        $updateStmt->execute([$username, $email, $profilePicFilename, $userId]);
    }
    $pdo->commit();
    $_SESSION['flash_success'] = 'Profile updated successfully.';
} else {
    // Rollback if there are any errors
    $pdo->rollback();
}
if (isset($_POST['reset_picture']) && $_POST['reset_picture'] == '1') {
    // Remove the existing profile picture file
    $existingPic = "profile_pictures/" . $userId . '.jpg';
    if (file_exists($existingPic)) {
        unlink($existingPic); // This deletes the file
    }

    // Update the profile_pic column to NULL or a default image path
    $updateQuery = "UPDATE users SET profile_pic = NULL WHERE id = ?";
    $updateStmt = $pdo->prepare($updateQuery);
    $updateStmt->execute([$userId]);
    $_SESSION['flash_success'] = 'Profile picture reset successfully.';
}
header('Location: profile.php');
exit;
?>
