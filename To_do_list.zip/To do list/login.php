<?php
session_start();
include 'list_database.php'; // Your PDO database connection script
$error_message = ""; // Initialize error message variable

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'Login') {
    $username = $_POST['login_username'];
    $password = $_POST['login_password'];

    // Prepare SQL to check if the username exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();

    // Fetch user from the database
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify the password and check if the user exists
    if ($user && password_verify($password, $user['password'])) {
        // Password is correct, so start the session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];

        // Redirect to the tasks page
        header('Location: tasks.php');
        exit;
    } else {
        // Authentication failed
        $login_error_message = "Incorrect username or password. Please try again.";
    }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'Register') {
        // Grab the form data
        $username = $_POST['register_username'];
        $password = $_POST['register_password'];
        $email = $_POST['register_email'];

        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Check if the user already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user) {
            $register_error_message = "User already exists.";
        } else {
            // Insert the new user
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
            $result = $stmt->execute([$username, $hashedPassword, $email]);
            
            if ($result) {
                $_SESSION['user_id'] = $pdo->lastInsertId(); // Set the user session ID
                $_SESSION['username'] = $username; // Set the username in session
                header('Location: tasks.php'); // Redirect to tasks page
                exit;
            } else {
                $_SESSION['error_message'] = "Registration failed.";
            }
        }
    } elseif ($_POST['action'] == 'Login') {
        
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login and Registration</title>
    <link rel="stylesheet" href="login.css"> <!-- Link to your CSS file -->
    <link rel="icon" type="image/png" href="listlogo.png">
</head>
<div class="forms-container">
<img src="cute list.png" alt="To-do list" class="corner-image">
    <div class="container" id="login-container" >
        <div class="heading">Login</div>
        <?php if (!empty($login_error_message)): ?>
            <p class="error-message"><?= htmlspecialchars($login_error_message); ?></p>
        <?php endif; ?>
        <form action="login.php" method="post" class="form">
            <input required class="input" type="text" name="login_username" id="login_username" placeholder="Username">
            <input required class="input" type="password" name="login_password" id="login_password" placeholder="Password">
            <input class="login-button" type="submit" name="action" value="Login">
        </form>
    </div>
    <div class="container" id="register-container">
        <div class="heading">Register</div>
        <?php if (!empty($register_error_message)): ?>
            <p class="error-message"><?= htmlspecialchars($register_error_message); ?></p>
        <?php endif; ?>
        <form action="login.php" method="post" class="form">
            <input required class="input" type="text" name="register_username" id="register_username" placeholder="Username">
            <input required class="input" type="password" name="register_password" id="register_password" placeholder="Password">
            <input required class="input" type="email" name="register_email" id="register_email" placeholder="Email">
            <input class="login-button" type="submit" name="action" value="Register">
        </form>
    </div>
    <img src="cute animal.png" alt="Cute animal" class="bottom-right-image"> <!-- Make sure 'src' is the correct path to your image
</div>
</body>
</html>