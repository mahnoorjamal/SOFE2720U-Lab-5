<?php
session_start();
include 'list_database.php';


if (!isset($_SESSION['user_id']) || !isset($_GET['task_id'])) {
    header('Location: tasks.php');
    exit;
}

$userId = $_SESSION['user_id'];
$taskId = $_GET['task_id'];

// Fetch the task details
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?");
$stmt->execute([$taskId, $userId]);
$task = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$task) {
    echo "Task not found.";
    exit;
}

// If form is submitted, update the task
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_task'])) {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $priority = $_POST['priority'] ?? '';
    $due_date = $_POST['due_date'] ?? '';

    // Update task query
    $stmt = $pdo->prepare("UPDATE tasks SET title = ?, description = ?, priority = ?, due_date = ? WHERE id = ? AND user_id = ?");
    if ($stmt->execute([$title, $description, $priority, $due_date, $taskId, $userId])) {
        header('Location: tasks.php');
        exit;
    } else {
        echo "Failed to update the task.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Task</title>
    <link rel="stylesheet" href="edit.css"> <!-- Use the same CSS file to maintain the style -->
    <link rel="icon" type="image/png" href="listlogo.png">
</head>
<body>
<div class="container">
    <div class="header-container">
            <h1>Edit Task</h1>
            <img src="question.png" alt="Edit Icon" class="greeting-image"/> <!-- Use an appropriate icon for edit -->
    </div>
    
    <div class="profile-section">
        <div class="left-column">
            <!-- If you have a specific image for the task or edit, include it here -->
        </div>
        
        <div class="profile-details">
            <form action="edit.php?task_id=<?= $task['id'] ?>" method="post">
                <div class="input-wrapper">
                    Title: <input type="text" name="title" value="<?= htmlspecialchars($task['title']) ?>" required>
                </div>
                <div class="input-wrapper">
                    Description: <textarea name="description" required><?= htmlspecialchars($task['description']) ?></textarea>
                </div>
                <div class="input-wrapper">
                    Priority: <select name="priority" required>
                        <option value="Low" <?= $task['priority'] === 'Low' ? 'selected' : '' ?>>Low</option>
                        <option value="Medium" <?= $task['priority'] === 'Medium' ? 'selected' : '' ?>>Medium</option>
                        <option value="High" <?= $task['priority'] === 'High' ? 'selected' : '' ?>>High</option>
                    </select>
                </div>
                <div class="input-wrapper">
                    Due Date: <input type="date" name="due_date" value="<?= $task['due_date'] ?>" required>
                </div>
                <div>
                    <button type="submit" name="update_task" class="learn-more">Update Task</button>
                </div>
            </form>
        </div>
    </div>
    <button onclick="window.location.href='tasks.php'" class="learn-more back-btn">Back to Tasks</button> <!-- Back button -->
</div>
</body>
</html>
