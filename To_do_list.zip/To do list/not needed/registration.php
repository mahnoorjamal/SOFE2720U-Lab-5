//Not needed
<?php
/*session_start();
include 'list_database.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'Register') {
        // Grab the form data
        $username = $_POST['register_username'];
        $password = $_POST['register_password'];
        $email = $_POST['register_email'];

        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Check if the user already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user) {
            echo "User already exists.";
        } else {
            // Insert the new user
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
            $result = $stmt->execute([$username, $hashedPassword, $email]);
            
            if ($result) {
                $_SESSION['user_id'] = $pdo->lastInsertId(); // Set the user session ID
                $_SESSION['username'] = $username; // Set the username in session
                header('Location: tasks.php'); // Redirect to tasks page
                exit;
            } else {
                $_SESSION['error_message'] = "Registration failed.";
            }
        }
    } elseif ($_POST['action'] == 'Login') {
        
    }
} */
?>
